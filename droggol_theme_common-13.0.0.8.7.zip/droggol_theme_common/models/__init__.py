# -*- coding: utf-8 -*-
# Copyright (c) 2019-Present Droggol. (<https://www.droggol.com/>)

from . import product_template
from . import website
from . import rating
from . import website_menu
from . import res_config_settings
